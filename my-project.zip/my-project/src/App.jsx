import { useEffect, useState } from 'react';

function App() {
  const [user, setUser] = useState(null);

  const fetchUser = async () => {
    const res = await fetch('https://randomuser.me/api/');
    const data = await res.json();
    setUser(data.results[0]);
    console.log(data);
  };

  useEffect(() => {
    fetchUser();
  }, []);

  if (!user) return <p>Loading...</p>;

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <img src={user.picture.large} alt="User" style={{ borderRadius: '50%' }} />
      <h2>{user.name.first} {user.name.last}</h2>
      <p>{user.email}</p>
      <p>{user.location.city}, {user.location.country}</p>
      <button onClick={fetchUser}>Get New User</button>
    </div>
  );
}

export default App;
